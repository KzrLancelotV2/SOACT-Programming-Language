package main.ast.nodes.expression.operator;

public enum UnaryOperator {
    NOT, MINUS, POST_INC, POST_DEC, PRE_INC, PRE_DEC, BRACKET
}
