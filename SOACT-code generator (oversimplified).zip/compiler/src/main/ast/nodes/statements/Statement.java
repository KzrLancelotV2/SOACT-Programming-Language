package main.ast.nodes.statements;

import main.ast.nodes.Node;

public abstract class Statement extends Node {}
