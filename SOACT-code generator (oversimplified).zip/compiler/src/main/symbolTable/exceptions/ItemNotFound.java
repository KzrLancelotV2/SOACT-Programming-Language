package main.symbolTable.exceptions;

public class ItemNotFound extends Exception{
}
